package com.example.fruitlens.ui.quiz

class QuizViewModel {
}