package com.example.fruitlens.ui.detection

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.example.fruitlens.databinding.ActivityResultDetectionBinding

class ResultDetectionActivity : AppCompatActivity() {
    private lateinit var binding: ActivityResultDetectionBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityResultDetectionBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val imageDetection = intent.getStringExtra(EXTRA_IMAGE_URI)

        val fruitName = intent.getStringExtra(EXTRA_CLASSIFICATIONS)

        binding.apply {
            tvResultDetection.text = fruitName.toString()
            Glide.with(this@ResultDetectionActivity)
                .load(imageDetection)
                .into(imageResult)
        }
        supportActionBar?.hide()
    }
    companion object {
        const val EXTRA_IMAGE_URI = "extra_image_uri"
        const val EXTRA_CLASSIFICATIONS = "extra_classications"
    }

}