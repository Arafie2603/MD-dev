package com.example.fruitlens.data.response

import com.google.gson.annotations.SerializedName

data class FruitResponse(
	@field:SerializedName("result")
	val result: String? = null,

	@field:SerializedName("uploadId")
	val uploadId: String? = null
)
