package com.example.fruitlens.ui.detection

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.fruitlens.data.repository.FruitRepository
import com.example.fruitlens.data.response.FruitResponse
import kotlinx.coroutines.launch
import retrofit2.HttpException
import java.io.File

class DetectionViewModel(private val repository: FruitRepository) : ViewModel() {

    private val _result = MutableLiveData<Result<FruitResponse>>().apply {
        value = Result.failure(Exception("Initial value"))
    }

    val result: LiveData<Result<FruitResponse>> = _result

    fun uploadImage(imageFile: File) {
        viewModelScope.launch {
            try {
                val response = repository.uploadImage(imageFile)
                _result.postValue(Result.success(response))
            } catch (e: HttpException) {
                _result.postValue(Result.failure(e))
            } catch (e: Exception) {
                _result.postValue(Result.failure(e))
            }
        }
    }
}
