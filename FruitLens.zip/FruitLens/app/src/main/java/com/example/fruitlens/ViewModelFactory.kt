package com.example.fruitlens

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.fruitlens.data.repository.FruitRepository
import com.example.fruitlens.data.repository.UserRepository
import com.example.fruitlens.ui.detection.DetectionViewModel
import com.example.fruitlens.ui.home.HomeViewModel
import com.example.fruitlens.ui.login.LoginViewModel
import com.example.fruitlens.ui.main.MainViewModel
import com.example.fruitlens.ui.signup.SignupViewModel

@Suppress("UNCHECKED_CAST")
class ViewModelFactory(
    private val userRepository: UserRepository? = null,
    private val fruitRepository: FruitRepository? = null
) : ViewModelProvider.Factory {

    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return when {
            modelClass.isAssignableFrom(LoginViewModel::class.java) -> {
                LoginViewModel(userRepository ?: throw IllegalArgumentException("UserRepository is required")) as T
            }
            modelClass.isAssignableFrom(SignupViewModel::class.java) -> {
                SignupViewModel(userRepository ?: throw IllegalArgumentException("UserRepository is required")) as T
            }
            modelClass.isAssignableFrom(HomeViewModel::class.java) -> {
                HomeViewModel(userRepository ?: throw IllegalArgumentException("UserRepository is required")) as T
            }
            modelClass.isAssignableFrom(MainViewModel::class.java) -> {
                MainViewModel(userRepository ?: throw IllegalArgumentException("UserRepository is required")) as T
            }
            modelClass.isAssignableFrom(DetectionViewModel::class.java) -> {
                DetectionViewModel(fruitRepository ?: throw IllegalArgumentException("FruitRepository is required")) as T
            }
            else -> throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
        }
    }
}
