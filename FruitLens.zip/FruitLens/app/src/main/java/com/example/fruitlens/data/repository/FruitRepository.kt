package com.example.fruitlens.data.repository

import com.example.fruitlens.data.api.FruitService
import com.example.fruitlens.data.pref.UserPreference
import com.example.fruitlens.data.response.FruitResponse
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import java.io.File

class FruitRepository private constructor(
    private val fruitService: FruitService,
    private val userPreference: UserPreference
){
    suspend fun uploadImage(imageFile: File): FruitResponse {
        val requestImageFile = imageFile.asRequestBody("image/jpeg".toMediaType())
        val multipartBody = MultipartBody.Part.createFormData(
            "image",
            imageFile.name,
            requestImageFile
        )
        return fruitService.uploadImage(multipartBody)
    }
    companion object {
        fun getInstance(
            fruitService: FruitService,
            userPreference: UserPreference
        ) = FruitRepository(fruitService, userPreference)
    }
}