package com.example.fruitlens.ui.quiz

import android.content.Intent
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.content.res.AppCompatResources
import androidx.core.content.ContextCompat
import com.example.fruitlens.R
import com.example.fruitlens.databinding.ActivityResultBinding
import com.example.fruitlens.ui.main.MainActivity

class ResultActivity : AppCompatActivity() {
    private lateinit var binding: ActivityResultBinding
    private var empty_star: Drawable ? = null
    private var game_over: Drawable ? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityResultBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val result = intent.getIntExtra(QuizActivity.SCORE, 0)

        val displayScore = getString(R.string.tv_score, result)
        val displayValue = getString(R.string.tv_result, result)
        val failed = getString(R.string.tv_failed)
        binding.apply {
            tvScore.text = displayScore
            tvResult.text = displayValue
            fabTry.setOnClickListener {
                val intent = Intent(this@ResultActivity, QuizActivity::class.java)
                startActivity(intent)
            }
            fabHome.setOnClickListener {
                val intent = Intent(this@ResultActivity, MainActivity::class.java)
                startActivity(intent)
            }
            empty_star = AppCompatResources.getDrawable(this@ResultActivity, R.drawable.empty_star)
            game_over = AppCompatResources.getDrawable(this@ResultActivity, R.drawable.game_over)
            when (result) {
                in 7..9 -> {
                    tvFailed.visibility = View.GONE
                    imageStar3.setImageDrawable(empty_star)
                }
                in 4..7 -> {
                    tvFailed.visibility = View.GONE
                    imageStar3.setImageDrawable(empty_star)
                    imageStar2.setImageDrawable(empty_star)
                }
                0 -> {
                    resultActivity.setBackgroundColor(ContextCompat.getColor(this@ResultActivity, R.color.red))
                    tvResult.visibility = View.GONE
                    imageResult.setImageDrawable(game_over)
                    imageStar3.setImageDrawable(empty_star)
                    imageStar2.setImageDrawable(empty_star)
                    imageStar1.setImageDrawable(empty_star)
                }
            }
        }


        supportActionBar?.hide()
    }
}