package com.example.fruitlens.ui.quiz.data

data class Question (
    val id: Int,
    val question: String,
    val image: Int,
    val optionOne: String,
    val optionTwo: String,
    val optionThree: String,
    val correctAnswer: Int
) {
    var shuffledOptions: List<String> = listOf(optionOne, optionTwo, optionThree)
    var newCorrectAnswer: Int = correctAnswer
        private set

    init {
        shuffleOptions()
    }

    fun shuffleOptions() {
        val options = mutableListOf(optionOne, optionTwo, optionThree)
        options.shuffle()
        shuffledOptions = options

        // Update new correct answer position
        newCorrectAnswer = options.indexOf(
            when (correctAnswer) {
                1 -> optionOne
                2 -> optionTwo
                3 -> optionThree
                else -> throw IllegalArgumentException("Invalid correct answer index")
            }
        ) + 1
    }
}
